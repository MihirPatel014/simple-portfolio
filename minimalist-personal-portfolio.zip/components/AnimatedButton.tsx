import React from 'react';

interface AnimatedButtonProps {
  href: string;
  children: React.ReactNode;
}

const AnimatedButton: React.FC<AnimatedButtonProps> = ({ href, children }) => {
  return (
    <a
      href={href}
      className="inline-block bg-slate-900 dark:bg-slate-100 text-white dark:text-slate-900 font-medium py-3 px-6 rounded-lg transition-all duration-300 ease-in-out hover:scale-105 hover:shadow-lg hover:shadow-slate-900/20 dark:hover:shadow-slate-100/20"
    >
      {children}
    </a>
  );
};

export default AnimatedButton;
