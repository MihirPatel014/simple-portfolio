import type { PortfolioData } from '../types';

export const portfolioData: PortfolioData = {
  name: "Alex Doe",
  title: "Senior Frontend Engineer",
  intro: "I build pixel-perfect, engaging, and accessible digital experiences. My passion lies in creating intuitive UIs that solve user problems and meet business goals.",
  contactEmail: "alex.doe@example.com",
  experience: [
    {
      years: "2021 — Present",
      role: "Senior Frontend Engineer",
      company: "Stripe",
      description: "Developed and maintained critical components for the main dashboard, improving user experience and performance. Led a team of 5 engineers in a major redesign project.",
      stack: ["React", "TypeScript", "Next.js", "Tailwind CSS", "GraphQL"]
    },
    {
      years: "2019 — 2021",
      role: "Software Engineer",
      company: "Shopify",
      description: "Worked on the core checkout experience, implementing new features and A/B tests that resulted in a 5% increase in conversion.",
      stack: ["Ruby on Rails", "React", "TypeScript", "GraphQL"]
    },
    {
      years: "2017 — 2019",
      role: "Frontend Developer",
      company: "Vercel",
      description: "Built and scaled frontend infrastructure for the Vercel platform, focusing on performance and developer experience.",
      stack: ["React", "JavaScript", "Styled Components", "Node.js"]
    }
  ],
  projects: [
    {
      name: "Project Nova",
      description: "A collaborative design tool that allows teams to work on wireframes and prototypes in real-time. Built with a focus on performance and a seamless user experience.",
      stack: ["React", "TypeScript", "Firebase", "Canvas API"],
      link: "#"
    },
    {
      name: "ChronoLog",
      description: "An open-source time-tracking application for freelancers. Features include project management, invoicing, and detailed reporting.",
      stack: ["Next.js", "Prisma", "PostgreSQL", "Tailwind CSS"],
      link: "#"
    },
    {
      name: "GeoGuess AI",
      description: "A fun geography game powered by AI. Players are shown a random street view image and have to guess its location on a map.",
      stack: ["SvelteKit", "Python", "Flask", "Leaflet.js"],
      link: "#"
    }
  ],
  articles: [
    {
      date: "Mar 2023",
      title: "The Art of State Management in Modern React",
      description: "A deep dive into various state management patterns in React, from hooks to external libraries, and when to use each.",
      tags: ["React", "State Management", "Architecture"],
      link: "#"
    },
    {
      date: "Dec 2022",
      title: "Building Performant UIs with Tailwind CSS",
      description: "Exploring how utility-first CSS can lead to highly performant and maintainable user interfaces without leaving your HTML.",
      tags: ["CSS", "Performance", "Tailwind CSS"],
      link: "#"
    },
    {
      date: "Jul 2022",
      title: "TypeScript for the Skeptical JavaScript Developer",
      description: "An introduction to TypeScript that focuses on its practical benefits for building robust and scalable applications.",
      tags: ["TypeScript", "JavaScript", "Web Dev"],
      link: "#"
    }
  ],
  links: [
    {
      name: 'GitHub',
      url: 'https://github.com'
    },
    {
      name: 'LinkedIn',
      url: 'https://linkedin.com'
    },
    {
      name: 'Email',
      url: 'mailto:alex.doe@example.com'
    },
    {
      name: 'Resume',
      url: '#'
    }
  ]
};
