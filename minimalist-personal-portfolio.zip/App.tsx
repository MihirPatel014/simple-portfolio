import React from 'react';
import Hero from './components/Hero';
import Experience from './components/Experience';
import Projects from './components/Projects';
import Articles from './components/Articles';
import Links from './components/Links';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-gray-100 dark:from-slate-900 dark:to-black text-slate-800 dark:text-slate-200 font-sans leading-relaxed selection:bg-sky-300/20">
      <div className="mx-auto min-h-screen max-w-screen-xl px-6 py-12 md:px-12 md:py-20 lg:px-24 lg:py-0">
        <div className="lg:flex lg:justify-between lg:gap-16">
          <header className="lg:sticky lg:top-0 lg:flex lg:max-h-screen lg:w-5/12 lg:flex-col lg:justify-between lg:py-24">
            <div>
              <Hero />
            </div>
            <Links />
          </header>

          <main id="content" className="pt-24 lg:w-7/12 lg:py-24">
            <div className="flex flex-col gap-16 md:gap-24">
              <Experience />
              <Projects />
              <Articles />
            </div>
            <Footer />
          </main>
        </div>
      </div>
    </div>
  );
}

export default App;
